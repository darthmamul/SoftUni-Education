﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=DARTHMAMUL-PC\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
