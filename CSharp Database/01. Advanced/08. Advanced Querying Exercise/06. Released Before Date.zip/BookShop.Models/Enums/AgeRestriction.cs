﻿namespace BookShop.Models
{
    public enum AgeRestriction
    {
        Minor,
        Teen,
        Adult
    }
}
